<?php
//000000000000s:34:"SELECT * FROM `extgrid` LIMIT 10  ";
?>