<?php
//000000000000s:37:"SELECT * FROM `extgrid` LIMIT 10,10  ";
?>