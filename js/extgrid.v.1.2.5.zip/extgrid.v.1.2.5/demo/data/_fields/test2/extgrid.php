<?php
return array ( 0 => 'username', 1 => 'age', 2 => 'sex', 3 => 'qq', 4 => 'email', 5 => 'address', 6 => 'info', 7 => 'birthday', 8 => 'itime', 9 => 'id', '_autoinc' => true, '_pk' => 'id', ); ?>