<?php
$_SC['DB_TYPE'] = 'mysql';
$_SC['DB_HOST'] = 'localhost';
$_SC['DB_NAME'] = 'test2';
$_SC['DB_USER'] = 'root';
$_SC['DB_PWD'] = '';
$_SC['DB_PORT'] = '';
$_SC['DB_CHARSET'] = 'utf8';
?>