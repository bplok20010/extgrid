<?php
return array ( 0 => 'wid', 1 => 'username', 2 => 'businessid', 3 => 'current_week', 4 => 'next_week', 5 => 'problem', 6 => 'week', 7 => 'idate', '_autoinc' => true, '_pk' => 'wid', ); ?>