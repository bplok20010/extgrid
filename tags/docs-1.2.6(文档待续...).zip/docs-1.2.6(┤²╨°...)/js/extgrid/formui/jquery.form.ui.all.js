/*
jquery.validator.js
nobo
Create On 
zere.nobo@gmail.com
*/
;(function($){
	$.formValid = {
		addMethod : function(name,func){
			var self = this;
			if( $.isFunction(func) ) {
				self.methods[name] = func;
			}
			return self;
		},
		methods : {
			required: function( value, param ) {
				return $.trim(value).length > 0;
			},
			email: function( value, param ) {
				return $.trim(value).length==0 || /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(value);
			},
			url: function( value, param ) {
				return $.trim(value).length==0 || /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);//'
			},
			ip : function( value, param ){
				return $.trim(value).length==0 || /^[\d\.]{7,15}$/.test(value);		
			},
			qq : function( value, param ){
				return $.trim(value).length==0 || /^[1-9]\d{4,12}$/.test(value);		
			},
			currency : function( value, param ){
				return $.trim(value).length==0 || /^\d+(\.\d+)?$/.test(value);		
			},
			mobile : function( value, param ){
				return $.trim(value).length==0 || /^((\(\d{3}\))|(\d{3}\-))?13[0-9]\d{8}?$|15[89]\d{8}?$/.test(value);	
			},
			phone : function( value, param ){
				return $.trim(value).length==0 || /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/.test(value);	
			},
			number: function( value, param ) {
				return $.trim(value).length==0 || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value);
			},
			digits: function( value, param ) {
				return $.trim(value).length==0 || /^\d+$/.test(value);
			},
			creditcard: function( value, param ) {
				
				if( $.trim(value).length==0 ) {
					return true;	
				}
				
				if ( /[^0-9 \-]+/.test(value) ) {
					return false;
				}
				var nCheck = 0,
					nDigit = 0,
					bEven = false;
	
				value = value.replace(/\D/g, "");
	
				for (var n = value.length - 1; n >= 0; n--) {
					var cDigit = value.charAt(n);
					nDigit = parseInt(cDigit, 10);
					if ( bEven ) {
						if ( (nDigit *= 2) > 9 ) {
							nDigit -= 9;
						}
					}
					nCheck += nDigit;
					bEven = !bEven;
				}
	
				return (nCheck % 10) === 0;
			},
			//checkLength 检验radio checkbox的选择数
			rangelength: function( value, param ) {
				if( $.trim(value).length==0 ) {
					return true;	
				}
				
				var length = value.split(",").length;
				//var length = $.isArray( value ) ? value.length : this.getLength($.trim(value), element);
				return ( length >= param[0] && length <= param[1] );
			},
			min: function( value, param ) {
				if( $.trim(value).length==0 ) {
					return true;	
				}
				return value >= param;
			},
			max: function( value, param ) {
				if( $.trim(value).length==0 ) {
					return true;	
				}
				return value <= param;
			},
			range: function( value, param ) {
				if( $.trim(value).length==0 ) {
					return true;	
				}
				return ( value >= param[0] && value <= param[1] );
			},
			equalTo: function( value, param ) {
				var target = $(param);
				return value === target.val();
			}
		},
		messages: {
			required: "This field is required.",
			remote: "Please fix this field.",
			email: "Please enter a valid email address.",
			url: "Please enter a valid URL.",
			date: "Please enter a valid date.",
			dateISO: "Please enter a valid date (ISO).",
			number: "Please enter a valid number.",
			digits: "Please enter only digits.",
			creditcard: "Please enter a valid credit card number.",
			equalTo: "Please enter the same value again."
		}
	};
	$.fn.formValid = function(){
		return 	$.formValid;
	};
})(jQuery);

/*
jquery.extForm.js
http://www.extgrid.com/form.ui
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

每个组件都应该提供或实现的接口 不提供则调用默认函数
组件名+Start
组件名+Create 必须
组件名+BindEvent 必须
组件名+Tpl
组件名+GetValue
组件名+SetValue
组件名+ValueChange
组件名+Extend
组件名+SizeChange
组件名+Disabled
组件名+Enable
组件名+Destroy
*/

;(function($){
	"use strict";
	$.extForm = function(options){
		this.init(options);
	};
	$.extForm.fn = {};
	$.extForm.fn.extend = function(obj){
		$.extend($.extForm.prototype,obj);
	};
	$.extForm.extend = function(obj){
		$.extend($.extForm,obj);	
	};
	$.extForm.extend({
		version : '1.0', 
		padding : 4,//单元格padding占用的宽度
		aid : 1, //自增编号 
		list : {},
		puglins : [],//调用插件初始化函数 参数 self
		get : function(name,group){
			var self = this;
			
			var group = self._undef( group , 'default' );
			
			var ls = [];
			
			var list = self.list;
			if( group in list ) {
				//for( var x in list[group] ) {
				for( var x=0;x<list[group].length;x++ ) {	
					var l = list[group][x];
					
					if( l === null ) continue;
					
					//同时判断当前对象是否存在
					if( !$( "#"+l.self.C('id') ).length ) {
						l.self._destroy();
						list[group][x] = null;
						continue;
					}
					
					if( l.name == name ) {
						ls.push(l.self);	
					}
				}
			}
			return ls.length == 1 ? ls[0] : ls;
		},
		getVal : function(name,group){
			var self = this;
			var obj = self.get.apply(self,arguments);
			var val = [];
			if( $.isArray(obj) ) {
				$.each(obj,function(){
					var _val = this.val();
					if( _val != '' ) {
						val.push( _val );	
					}
				});
				return val.join(",");	
			} else {
				return obj.val();		
			}
			return null;
		},
		setVal : function(value,name,group){
			var self = this;
			var obj = self.get.apply(self,[arguments[1],arguments[2]]);
			var val = [];
			if( $.isArray(obj) ) {
				$.each(obj,function(){
					this.val(value);
				});
				return true;
			} else {
				obj.val(value);		
				return true;
			}
			return null;
		},
		//获取某分组下的所有值
		getGroupVal : function(group){
			var self = this;
			var group = self._undef( group , 'default' );	
			var list = self.list;
			var data = {};
			if( group in list ) {
				for( var x=0;x<list[group].length;x++ ) {
					var l = list[group][x];
					if( l === null ) continue;
					data[ l.name ] = $.extForm.getVal( l.name,group );
				}	
			}	
			return data;
		},
		//验证是否通过，并返回错误的字段name
		checkGroup : function(group) {
			var self = this;
			var group = self._undef( group , 'default' );	
			var list = self.list;
			var errorList = [];
			var r;
			if( group in list ) {
				//for( var x in list[group] ) {
				for( var x=0;x<list[group].length;x++ ) {
					var l = list[group][x];
					if( l === null ) continue;
					r = l.self.checkVal();
					if( r === false ) {
						errorList.push(l.name);	
					}
				}	
			}
			return errorList.length ? errorList : true;
		},
		//验证是否通过
		valid : function(group){
			var self = this;
			var r = self.checkGroup(group);
			return r === true ? true : false;
		},
		//验证某一元素
		checkElement : function( name,group ){
			var self = this;
			var obj = self.get.apply( self,arguments );
			if( $.isArray(obj) ) {
				obj = obj[0];
			}
			return obj.checkVal();
		},
		getDefaults : function(opt){
			var _opt = {
				id : '',
				init : $.noop,
				padding : $.extForm.padding,
				label : '',
				labelCls : '',
				display : 'inline-block',
				group : 'default',//分组
				name : '',
				value : '',
				url : '',//支持远程创建 返回数据格式  json
				dataType : 'json',
				method : 'get',
				parames : {},
				validator : $.formValid || {},
				rules : [],
				messages : {},
				error : 'valid-error',
				items : [],//{cls:'',name:'abs',value:'45',readOnly:false,disabled:false,selected:true,attrs:''} or '|' ',' ';'
				_item :　{
					cls:'',
					name:'',
					value:'',
					readOnly:false,
					disabled:false,
					selected:false,
					attrs:''
				},
				renderTo : null,
				leftText : '',
				rightText : '',
				width : 150,
				height : 60,//textarea
				step : 1,//spinner,
				smax : null,//spinner,
				smin : null,//spinner,
				type : 'text',
				onCheck : ['onBlur','onPaste'],//什么时候进行数据验证
				disabled : false,
				readOnly : false,
				cls : '',
				attrs : '',//用户自定义属性
				template : null,
				cacheData : [],
				_oldVal : '',
				tpl : {},
				events : {
					onStart : $.noop,
					onCreate : $.noop,
					onSizeChange : $.noop,
					onClick : $.noop,
					onFocus : $.noop,
					onBlur : $.noop,
					onKeyDown : $.noop,
					onKeyUp : $.noop,
					onKeyPress : $.noop,
					onMouseOver : $.noop,
					onMouseOut : $.noop,
					onPaste : $.noop,
					onSpinnerUp : $.noop,
					onSpinnerDown : $.noop,
					onBeforeSet : $.noop,
					onAfterSet : $.noop,
					onBeforeGet : $.noop,
					onAfterGet : $.noop,
					onChange : $.noop,
					onValidError : $.noop,
					onValidSuccess : $.noop,
					onDestroy : $.noop
				}
			};
			return $.extend(_opt,opt);
		},
		_undef : function (val, defaultVal) {
			return val === undefined ? defaultVal : val;
		},
		_Tpl : {}
		
	});
	$.extForm.fn.extend({
		init : function(options) {
			var self = this;
			var options = $.extForm._undef( options , {} );
			self.configs = 	$.extend(true,{},$.extForm.getDefaults(),options);
			
			var opt = self.configs;
			opt.self = self;
			
			opt.id = opt.id || self.getId();
			
			opt.type = opt.type.toLowerCase();
			
			self.initEvents();
			
			//系统初始化调用
			opt.init.call(self,opt);
			
			self.loadPuglins();
			
			self.sysEvents();
			
			self.fireEvent("onStart",[opt]);
			
			
			if( opt.url ) {
				self.getConf();//获取远程配置后创建
			} else {
				self.create();
			}
			
		},
		initEvents : function(){
			var self = this;
			var opt = self.configs;
			var events = opt.events;
			for( var x in events ) {
				if( x in opt ) {
					self.bind(x,opt[x],self);	
				}	
			}
		},
		addList : function(){
			var self = this;
			var opt = self.configs;
			var list = $.extForm.list;
			if( opt.group in list ) {
				list[ opt.group ].push( {
					name : opt.name,
					'self' : self
				} );	
				
			} else {
				list[ opt.group ] = [];
				list[ opt.group ].push( {
					name : opt.name,
					'self' : self
				} );
			}
		},
		//获取周围可显示空间
		getShowSpace : function(){
			var self = this;
			var opt = self.configs;
			//需要获取的对象
			var obj = $("#"+opt.id);
			
			//获取窗口显示区域大小
			var cw = $(window).width();
			var ch = $(window).height();
			
			var offset = obj.offset();
			
			//获取滚位置
			var sLeft = $(window).scrollLeft();
			var sTop = $(window).scrollTop();
			
			var space = {
				top : offset.top - sTop,
				left : offset.left - sLeft
			};
			space.bottom = ch - space.top - obj.outerHeight();
			space.right = cw - space.left - obj.outerWidth();
			return space;
			
		},
		_undef : function (val, d) {
			return val === undefined ? d : val;
		},
		inArray : function(elem,arr){
			if ( arr ) {
				var len = arr.length;
				var i = 0;
				for ( ; i < len; i++ ) {
					// Skip accessing in sparse arrays
					if ( i in arr && arr[ i ] == elem ) {
						return i;
					}
				}
			}
			return -1;
		},
		/**
		 * 模板处理函数(用户自定义模版级别最高,其次模板函数,最后_Tpl中的模版)
		 *  @tpl {String,Function} 模板内容
		 *  @data {Object} 模板数据
		 *  @return {String} 模板内容
		 */
		tpl : function(tpl,data){
			var self = this;
			var opt = self.configs;
			if( typeof tpl == 'undefined' ) tpl = "";
			if( typeof data == 'undefined' ) data = {};
			
			var html = "";
			if( $.isFunction(tpl) ){
				html = tpl.call(self,data);
			} else if( (tpl+'Tpl') in self ) {
				html = self[tpl+'Tpl'](data);
			} else {
				html = tpl;
			}
			return html;
		},
		/*
		* 不触发被调用API里的事件(部分函数除外 例如setGridBody,因为里面通过计时器触发)
		*  @param1 {String} 需要调用的API
		*  @param2~N 被调用的API参数(可选)
		*/
		denyEventInvoke : function(){//method,arg1,arg2....
			var self = this;
			var r;
			if( arguments.length ){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push(arguments[i]);	
				}
				var method = argvs[0];
				if( method in self ) {
					self._denyEvent = true;
					argvs.splice(0,1);
					r = self[method].apply(self,argvs);
					self._denyEvent = false;
				}
			}
			return r;
		},
		/*
		* API调用管理,作用在于通过该函数调用的会过滤被锁定的函数
		*  @param1 {String} 需要调用的API
		*  @param2~N 被调用的API参数(可选)
		*/
		methodInvoke : function(){//method,arg1,arg2....
			var self = this;
			var r;
			
			var methodLocks = self._methodLocks || {};
			
			if( arguments.length ){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push(arguments[i]);	
				}
				var method = argvs[0];
				
				if( methodLocks[method] ) {
					return;	
				}
				
				if( method in self ) {
					argvs.splice(0,1);
					r = self[method].apply(self,argvs);
				}
			}
			return r;
		},
		/*
		* 事件绑定
		*  @eventType {String} 事件名
		*  @func      {Function} 事件回调
		*  @scope     {Object} this对象(可选)
		*  @return    {int} 事件ID or false
		*/
		bind : function(eventType,func,scope){
			if( typeof eventType == "undefined" ) {
				return false;	
			}
			var func = func || $.noop;
			var self = this;
			var event = self.configs.events;
			
			var _type = eventType.split(".");
			eventType = _type[0];
			var ext = _type.length == 2 ? _type[1] : '';
			
			event[eventType] = self._undef(event[eventType],[]);
			
			if( $.isFunction( event[eventType] ) ) {
				event[eventType] = [];
			}
			
			var _e = {
					scope : !!scope ? scope : self,
					func : func,
					ext : ext
				};
			
			var id = event[eventType].push(_e);
		
			return id-1;
		},
		/*
		*同bind 区别在于只执行一次
		*/
		one : function(eventType,func,scope){
			if( typeof eventType == "undefined" ) {
				return false;	
			}
			var func = func || $.noop;
			var self = this;
			var scope = !!scope ? scope : self;
			
			var _ = function(){
					self.unbind(eventType,_.id);
					var r = func.apply(scope,arguments);
					return r;
				},
				id = null;
				
			id = self.bind( eventType,_,scope );
			_.id = id;
			return id;
		},
		/*
		* 取消事件绑定
		*  @eventType {String} 事件名
		*  @id        {int} 事件ID(可选)
		*/
		unbind : function(eventType,id){
			var self = this;
			var event = self.configs.events;
			var id = self._undef(id,false);
			
			var _type = eventType.split(".");
			eventType = _type[0];
			var ext = _type.length == 2 ? _type[1] : '';
			
			if( !(eventType in event) ) {
				return self;	
			}
			
			if( $.isFunction( event[eventType] ) ) {
				event[eventType] = [];
				return self;
			}
			
			if(id === false) {
				if( ext == '' ) {
					event[eventType] = [];
				} else {
					
					var j = 0;//用于splice
					for(var i=0;i<event[eventType].length;i++) {
						var _e = event[eventType][i];
						if( $.isPlainObject( _e ) && _e.ext == ext ) {
							event[eventType][i] = null;	
							j++;
						}
					}
					//不能采取splice方式删除，否则事件ID会打乱
					/*for( var k=0;k<j;k++ ) {
						for(var i=0;i<event[eventType].length;i++) {
							var _e = event[eventType][i];
							if( $.isFunction( _e ) && _e === null ) {
								event[eventType].splice(i,1);
								break;
							}
						}	
					}*/
				}
			} else {
				event[eventType][id] = null;	
				/*try{
					event[eventType].splice(id,1);
				} catch(e){
					event[eventType][id] = null;	
				}*/
			}
			return self;
		},
		/*
		* 锁定API
		*  @method {String} API名
		*/
		lockMethod : function(method){
			var self = this;	
			//事件锁
			var methodLocks = self._methodLocks || {};
			methodLocks[method] = true;
			self._methodLocks = methodLocks;
			return true;	
		},
		/*
		* 取消锁定API
		*  @method {String} API名
		*/
		unLockMethod : function(method){
			var self = this;	
			//事件锁
			var methodLocks = self._methodLocks || {};
			methodLocks[method] = false;
			self._methodLocks = methodLocks;
			return true;	
		},
		/*
		* 锁定事件
		*  @eventType {String} 事件名
		*/
		lockEvent : function(eventType){
			var self = this;	
			//事件锁
			var eventLocks = self._eventLocks || {};
			eventLocks[eventType] = true;
			self._eventLocks = eventLocks;
			return true;
		},
		/*
		* 取消锁定事件
		*  @eventType {String} 事件名
		*/
		unLockEvent : function(eventType){
			var self = this;	
			//事件锁
			var eventLocks = self._eventLocks || {};
			eventLocks[eventType] = false;
			self._eventLocks = eventLocks;
			return true;
		},
		/*
		* 事件触发
		*  @eventType {String} 事件名
		*  @data      {Array} 事件参数(可选)
		*/
		fireEvent : function(eventType,data){
			var self = this;
			
			if( self._denyEvent ) {
				return;	
			}
			
			var events = self.configs.events[eventType];
			//var scope = self._undef(scope,self);
			var data = self._undef(data,[]);
			//添加事件锁
			var eventLocks = self._eventLocks || {};
			if( eventLocks[eventType] ) {
				return;	
			}
			eventLocks[eventType] = true;
			
			var r = true;
			if($.isArray(events) ) {
				var len = events.length;
				for(var i=0;i<len;i++) {
					var _e = events[i];
					if( $.isPlainObject( _e ) ) {
						r = _e.func.apply(_e.scope,data);
					} else if( $.isFunction( _e ) ){
						r = _e.apply(self,data);
					}
					if(r === false) break;	
				}	
				
			} else if($.isFunction(events)) {
				r = events.apply(self,data);
			}
			//取消事件锁
			eventLocks[eventType] = false;
			
			return r;
		},
		loadPuglins : function(){
			var self = this;
			$.each( $.extForm.puglins,function(i){
				if( $.isFunction( this ) )
					this.call(self);									
			} );
		},
		getId : function(){
			return 'extform_'+$.extForm.aid++;	
			//return 'extgrid_' + Math.floor(Math.random() * 99999);	
		},
		unique : function(){
			return 'unique_' + Math.floor(Math.random() * 99999);		
		},
		sysEvents : function(){
			var self = this;
			var opt = self.configs;
			
			self.bind("onStart",self.onStart,self);
			
			self.bind("onCreate",self.onCreate,self);
			self.bind("onCreate",self.addList,self);
			//self.bind("onCreate",self.loadPuglins,self);
			self.bind("onCreate",self.onDisabled,self);
			
			self.bind("onSizeChange",self.onSizeChange,self);
			self.bind("onMouseOver",self.onMouseOver,self);
			self.bind("onMouseOut",self.onMouseOut,self);
			self.bind("onBeforeGet",self.onBeforeGet,self);
			self.bind("onAfterGet",self.onBeforeGet,self);
			self.bind("onBeforeSet",self.onBeforeSet,self);
			self.bind("onAfterSet",self.onAfterSet,self);
			self.bind("onChange",self.onChange,self);
			self.bind("onValidError",self.onValidError,self);
			self.bind("onValidSuccess",self.onValidSuccess,self);
			for(var i=0;i<opt.onCheck.length;i++ ) {
				var s = self.bind(opt.onCheck[i],self.onCheck,self);	
			}
			return self;
		},
		
		
		onValidError : function(){
			var self = this;
			var opt = self.configs;
			$("#"+opt.id).removeClass(opt.error);
			$("#"+opt.id).addClass(opt.error);
		},
		onValidSuccess : function(){
			var self = this;
			var opt = self.configs;
			$("#"+opt.id).removeClass(opt.error);
		},
		onCreate : function(){
			var self = this;
			var opt = self.configs;
			var method = opt.type + 'Extend';
			if( method in self ) {
				self[method].call(self);
			}
		},
		onStart : function(){
			var self = this;
			var opt = self.configs;
			
			opt.cls += ' form-'+opt.type+'-ui form-'+opt.group+'-ui ';
			
			if(opt.disabled){
				opt.attrs += 'disabled';
			}
			if(opt.readOnly){
				opt.attrs += ' readOnly ';
			}
			if(opt.display != 'inline-block'){
				opt.display = ' display:'+opt.display+'; ';
			}
			
			var method = opt.type + 'Start';
			if( method in self ) {
				self[method].call(self);
			}
		},
		onDisabled : function(){
			var self = this;
			var opt = self.configs;
			if( opt.disabled ) {
				self.disabled();
				$("#"+opt.id).addClass('form-'+opt.type+'-ui-disabled');
			}
		},
		//自动销毁时调用
		_destroy : function(){
			var self = this;
			var opt = self.configs;
			
			var method = opt.type+'Destroy';
			if( method in self ) {
				self[method].apply(self,[]);
			}
			self.fireEvent("onDestroy");
			return self;
		},
		onSizeChange : function(width){
			var self = this;
			var opt = self.configs;
			
			var method = opt.type+'SizeChange';
			if( method in self ) {
				self[method].apply(self,[width]);
				return;
			}

			var width = $.extForm._undef( width , parseFloat(opt.width) );
			
			opt.width = width;

			var text = $("#"+opt.id+"_text");
			var input = $("#"+opt.id+"_input");
			var buttons = $(">span.ui-form-buttons",text).first();
			text.width( width );
			var lw = 0;
			if( buttons.length ) {
				lw = buttons.outerWidth();
			}
			input.width( width - lw - opt.padding );
			
			$("#"+opt.id).height( $("#"+opt.id+"_box").outerHeight() );
		},
		onMouseOver : function(t,e){
			$(t).closest("span.ui-form-input")
			.addClass('ui-form-over');
		},
		onMouseOut : function(t,e){
			$(t).closest("span.ui-form-input")
			.removeClass('ui-form-over');
		},
		onBeforeGet : function(){
				
		},
		onAfterGet : function(){
			
		},
		onBeforeSet : function(){
			var self = this;
			var opt = self.configs;
			opt._oldVal = opt._oldVal === null ? self.val() : opt._oldVal;
		},
		onAfterSet : function(){
			var self = this;
			var opt = self.configs;
			var newVal = self.val();
			if( opt._oldVal != newVal && opt._oldVal!==null ) {
				opt._oldVal = null;
				self.fireEvent('onChange',[]);	
			}
		},
		onCommonChange : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input");
			if( !input.length || !input.is(":input") ) {
				return self;	
			}
			
			var input_key = $("#"+opt.id+"_input_key");
			if( !input_key.length || !input_key.is(":input") ) {
				return self;	
			}
			
			input_key.val( input.val() );
			return self;	
		},
		onChange : function(){
			var self = this;
			var opt = self.configs;
			var method = opt.type+'ValueChange';
			if( method in self ) {
				self[method].apply(self,[]);	
			} else {
				self.onCommonChange.apply(self,[]);
			}
		},
		onCheck :　function(){
			var self = this;
			var opt = self.configs;	
			self.checkVal();
		},
		commonDisabled : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input");
			if( !input.length ) {
				var text = $("#"+opt.id+"_text");
				var obj = text.find("input[name="+opt.name+"]");
				//radio
				if( obj.is(":radio") ) {
					obj.each(function(){
						$(this).attr('disabled',true);	  
					});
				} else if( obj.is(":checkbox") ) {//checkbox
					obj.each(function(){
						$(this).attr('disabled',true);	  
					});
				}
				
			} else {
				input.attr('disabled',true);	  
			}
			return self;	
		},
		disabled : function(){
			var self = this;
			var opt = self.configs;
			var method = opt.type + 'Disabled';
			if( method in self ) {
				self[method].call(self);
			} else {
				self.commonDisabled();
			}
		},
		commonEnable : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input");
			if( !input.length ) {
				var text = $("#"+opt.id+"_text");
				var obj = text.find("input[name="+opt.name+"]");
				//radio
				if( obj.is(":radio") ) {
					obj.each(function(){
						$(this).attr('disabled',false);	  
					});
				} else if( obj.is(":checkbox") ) {//checkbox
					obj.each(function(){
						$(this).attr('disabled',false);	  
					});
				}
				
			} else {
				input.attr('disabled',false);	  
			}
			return self;	
		},
		enable : function(){
			var self = this;
			var opt = self.configs;
			var method = opt.type + 'Enable';
			if( method in self ) {
				self[method].call(self);
			} else {
				self.commonEnable();
			}	
			$("#"+opt.id).removeClass('form-'+opt.type+'-ui-disabled');
		},
		commonReadOnly : function( flag ){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input");
			if( !input.length ) {
				var text = $("#"+opt.id+"_text");
				var obj = text.find("input[name='"+opt.name+"']");
				//radio
				if( obj.is(":radio") ) {
					obj.each(function(){
						$(this).attr('readonly',flag);	  
					});
				} else if( obj.is(":checkbox") ) {//checkbox
					obj.each(function(){
						$(this).attr('readonly',flag);	  
					});
				}
				
			} else {
				input.attr('readonly',flag);	  
			}
			return self;	
		},
		readOnly : function( flag ){
			var self = this;
			var opt = self.configs;
			
			var flag = typeof flag == 'undefined' ? true : flag;
			
			var method = opt.type + 'ReadOnly';
			if( method in self ) {
				self[method].call(self,flag );
			} else {
				self.commonReadOnly( flag  );
			}	
			$("#"+opt.id).removeClass('form-'+opt.type+'-ui-readonly');
		},
		getInput : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input");
			return input;
		},
		getInputKey : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input_key");
			return input;
		},
		"focus" : function(){
			var self = this;
			self.getInput().focus();
		},
		"select" : function(){
			var self = this;
			self.getInput().select();
		},
		"blur" : function(){
			var self = this;
			self.getInput().blur();
		},
		checkVal : function(){
			var self = this;
			var opt = self.configs;
			var r = true;
			var rules = opt.rules;
			var validator = opt.validator;
			var rule;
			//var value = self.val();
			var value = $.extForm.getVal( opt.name,opt.group );
			var checkList = {};//验证函数
			if( $.isArray( rules ) && rules.length ) {
				for( var x=0;x<rules.length;x++ ) {
					rule = rules[x];
					if( $.isFunction(rule) ) {
						//r = rule.call(self,value);
						checkList[x] = rule;
					} else if( $.isPlainObject(rule) ){
						for(var i in rule ) {
							if( $.isFunction( rule[i] ) ) {
								//r = rule[i].call(self,value);
								checkList[i] = rule[i];
							}else if( i in validator.methods ) {
								//r = validator.methods[i].call(self,value,rule[i]);
								checkList[i] = { method : i,params : rule[i] };
							}
						}
					} else {
						if( rule in validator.methods ) {
							//r = validator.methods[rule].call(self,value);
							checkList[rule] = rule;
						}
					}
				}
			} else if( typeof rules == 'string' ) {
				if( rule in validator.methods ) {
					//r = validator.methods[rule].call(self,value);
					checkList[rule] = rule;
				}	
			}
			for( rule in checkList ) {
				if( $.isFunction( checkList[rule] ) ) {
					r = checkList[rule].call( self,value );
					if( r === false) break;
				} else if( $.isPlainObject(checkList[rule]) ) {
					if( checkList[rule].method in validator.methods ) {
						r = validator.methods[ checkList[rule].method ].call(self,value,checkList[rule].params);
						if( r === false) break;
					}	
				} else {
					if( rule in validator.methods ) {
						//r = validator.methods[rule].call(self,value);
						r = validator.methods[rule].call(self,value);
						if( r === false) break;
					}	
				}
			}
			
			if( r === false ) {
				var errorMsg = opt.messages[rule] || validator.messages[rule] || rule;
				self.fireEvent("onValidError",[errorMsg]);	
			} else {
				self.fireEvent("onValidSuccess",[]);		
			}
			
			return r;
		},
		//获取数据
		val : function(){
			var self = this;
			var opt = self.configs;
			
			//设置当前值
			if( arguments.length ) {
				self.fireEvent('onBeforeSet',[]);	
				var method = opt.type+'SetValue';
				if( method in self ) {
					self[method].apply(self,arguments);	
				} else {
					self.commonSetValue.apply(self,arguments);
				}
				self.fireEvent('onAfterSet',[]);	
				return self;
			}
			
			var value = '';
			
			self.fireEvent('onBeforeGet',[]);	
			
			var method = opt.type+'GetValue';
			if( method in self ) {
				value = self[method].call(self);	
			} else {
				value = self.commonGetValue();
			}
			
			self.fireEvent('onAfterGet',[]);	
			
			return value;
		},
		//根据type创建控件
		create : function(){
			var self = this;
			var opt = self.configs;
			
			var method = opt.type+'Create';
			var bindEvent = opt.type+'BindEvent';
			
			var tpl = '';
			
			if( method in self ) {
				var r = self[method].call(self);
				if( r === false ) return false;
			
				if( bindEvent in self ) {
					self[bindEvent].call(self);
				}
				
				self.fireEvent('onSizeChange',[]);
				self.fireEvent('onCreate',[opt.helper]);
				
			}
			return true;
		},
		commonEvent : function(){
			var self = this;
			var opt = self.configs;
			
			var events = {
				'click' : function(e) {
					
					var r = self.fireEvent('onClick',[ this,e ]);	
					if( r === false ) return false;
					
				},
				'focus' : function(e) {
					
					$(this).closest("span.ui-form-input")
						   .addClass('ui-form-focus');
					
					var r = self.fireEvent('onFocus',[ this,e ]);	
					if( r === false ) return false;
					
				},
				'blur' : function(e) {
					var val = $(this).val();
					
					$(this).closest("span.ui-form-input")
						   .removeClass('ui-form-focus');
					
					var r = self.fireEvent('onBlur',[ this,e ]);	
					if( r === false ) return false;
					
				},
				'keydown' : function(e) {
					opt._oldVal = opt._oldVal === null ? $(this).val() : opt._oldVal;
					
					var r = self.fireEvent('onKeyDown',[ this,e ]);	
					if( r === false ) return false;
					
				},
				'keyup' : function(e) {
					var val = $(this).val();
					if( opt._oldVal != val && opt._oldVal!==null ) {
						
						var r = self.fireEvent('onChange',[ this,opt._oldVal,val,e ]);	
						opt._oldVal =null;
						if( r === false ) return false;
					}
					
					var r = self.fireEvent('onKeyUp',[ this,e ]);	
					if( r === false ) return false;
					
					
				},
				'keypress' : function(e){
					
					var r = self.fireEvent('onKeyPress',[ this,e ]);	
					if( r === false ) return false;
					
				},
				'mouseenter' : function(e){
					
					var r = self.fireEvent('onMouseOver',[ this,e ]);	
					if( r === false ) return false;
					
				},
				'mouseleave' : function(e){
					
					var r = self.fireEvent('onMouseOut',[ this,e ]);	
					if( r === false ) return false;
				
				},
				'change' : function(e){
					var r = self.fireEvent('onChange',[ this,e ]);	
					if( r === false ) return false;	
				},
				'paste' : function(e){
					
					var r = self.fireEvent('onPaste',[ this,e ]);	
					if( r === false ) return false;
					
				}
			};
			
			var input = $("#"+opt.id+"_input");
			
			input.bind(events);
			
			var text = $("#"+opt.id+"_text");
			
			text.bind("click",function(){
				//return false;						   
			});
			
			$(">span.ui-form-buttons",text).bind({
				click : function(e){
					var r = self.fireEvent('onClick',[ input,e ]);	
					if( r === false ) return false;
				},
				'mouseenter' : function(e){
					
					var r = self.fireEvent('onMouseOver',[ input,e ]);	
					if( r === false ) return false;
					
				},
				'mouseleave' : function(e){
					
					var r = self.fireEvent('onMouseOut',[ input,e ]);	
					if( r === false ) return false;
				
				}							 
			});
			
		},
		//通用获取
		commonGetValue : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input_key");
			
			var value = '';
			
			if( !input.length ) {
				input = $("#"+opt.id+"_input");	
			}
			
			if( !input.length ) {
				var text = $("#"+opt.id+"_text");
				var obj = text.find("input[name='"+opt.name+"']");
				//radio
				if( obj.is(":radio") ) {
					value = text.find(":radio[name='"+opt.name+"']:checked").val();
				} else if( obj.is(":checkbox") ) {//checkbox
					value = [];
					text.find(":checkbox[name='"+opt.name+"']:checked").each(function(){ 
						value.push( $(this).val() ); 
					})
					value = value.join(",");
				}
				
			} else {
				if( input.is(":input") )
					value = input.val();	
			}
			return $.trim(value);
		},
		//通用设置
		commonSetValue : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input");
			var input_key = $("#"+opt.id+"_input_key");	
			
			input.val(arguments[0]);
			input_key.val(arguments[0]);
			
			return self;
		},
		/*textGetValue : function(){
			var self = this;
			return self.commonGetValue();
		},*/
		textTpl :　function(d){
			if( !d ) return "";
			var self = this,
				opt = self.configs;
			var text = [];
			text.push('<span ui-form-group="'+d.group+'" style="'+d.display+'" class="ui-form-wraper '+d.cls+'" id="'+d.id+'">');
				text.push('<label for="'+d.id+'_input" class="ui-form-label '+d.labelCls+'">'+d.label+'</label>');
				text.push('<span class="ui-form-span ui-form-left-text">'+d.leftText+'</span>');
				text.push('<span class="ui-form-box" id="'+d.id+'_box">');
					text.push('<span class="ui-form-input ui-form-text" id="'+d.id+'_text" style=" width:0px;">');
						text.push('<input '+d.attrs+' type="text" id="'+d.id+'_input"  style=" width:0px"  value="'+d.value+'" /><input type="hidden" name="'+opt.name+'" id="'+d.id+'_input_key"  value="'+d.value+'" />');
						text.push('<span class="ui-form-buttons"></span>');
					text.push('</span>');
				text.push('</span>');
				text.push('<span class="ui-form-span ui-form-right-text">'+d.rightText+'</span>');
				text.push('<span class="ui-form-clear"></span>');
			text.push('</span>');
			return text.join("");
		},
		textBindEvent : function(){
			var self = this;
			self.commonEvent();
		},
		textCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var render = $(opt.renderTo);
			
			var wraper = $( self.tpl(opt.type.toString(),opt) );
			
			if( render.length ) {
				render.append( wraper );
			} else {
				target.after( wraper ).remove();
			}
			opt.helper = wraper;
			
		},
		comboTpl :　function(d){
			if( !d ) return "";
			var self = this,
				opt = self.configs;
			var text = [];
			text.push('<span ui-form-group="'+d.group+'" style="'+d.display+'" class="ui-form-wraper '+d.cls+'" id="'+d.id+'">');
				text.push('<label for="'+d.id+'_input" class="ui-form-label '+d.labelCls+'">'+d.label+'</label>');
				text.push('<span class="ui-form-span ui-form-left-text">'+d.leftText+'</span>');
				text.push('<span class="ui-form-box" id="'+d.id+'_box">');
					text.push('<span class="ui-form-input ui-form-text" id="'+d.id+'_text" style=" width:0px;">');
						text.push('<input '+d.attrs+' type="text"  id="'+d.id+'_input"  style=" width:0px"  value="'+d.value+'" /><input type="hidden" name="'+opt.name+'" id="'+d.id+'_input_key" value="'+d.value+'" />');
						text.push('<span class="ui-form-buttons">');
						
							text.push('<span class="ui-form-buttons-'+d.type+'">');
								text.push('<span class="ui-form-buttons-'+d.type+'-icon"></span>');			
							text.push('</span>');		
								
						text.push('</span>');
					text.push('</span>');
				text.push('</span>');
				text.push('<span class="ui-form-span ui-form-right-text">'+d.rightText+'</span>');
				text.push('<span class="ui-form-clear"></span>');
			text.push('</span>');
			return text.join("");
		},
		comboBindEvent : function(){
			var self = this;
			self.commonEvent();
			
			return self;
		},
		comboCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var wraper = $( self.tpl(opt.type,opt) );
			
			target.after( wraper ).remove();
			
			opt.helper = wraper;
			
		},
		spinnerTpl : function(d){
			if( !d ) return "";
			var self = this,
				opt = self.configs;
			var text = [];
			text.push('<span ui-form-group="'+d.group+'" style="'+d.display+'" class="ui-form-wraper '+d.cls+'" id="'+d.id+'">');
				text.push('<label for="'+d.id+'_input" class="ui-form-label '+d.labelCls+'">'+d.label+'</label>');
				text.push('<span class="ui-form-span ui-form-left-text">'+d.leftText+'</span>');
				text.push('<span class="ui-form-box" id="'+d.id+'_box">');
					text.push('<span class="ui-form-input ui-form-text" id="'+d.id+'_text" style=" width:0px;">');
						text.push('<input '+d.attrs+' type="text"  id="'+d.id+'_input"  style=" width:0px"  value="'+d.value+'" /><input type="hidden" name="'+opt.name+'" id="'+d.id+'_input_key" value="'+d.value+'" />');
						text.push('<span class="ui-form-buttons">');
						
							text.push('<span class="ui-form-buttons-'+d.type+'">');
								text.push('<span class="ui-form-buttons-'+d.type+'-icon">');
									text.push('<span class="ui-form-'+d.type+'-up"></span>');	
									text.push('<span class="ui-form-'+d.type+'-down"></span>');	
								text.push('</span>');
							text.push('</span>');		
								
						text.push('</span>');
					text.push('</span>');
				text.push('</span>');
				text.push('<span class="ui-form-span ui-form-right-text">'+d.rightText+'</span>');
				text.push('<span class="ui-form-clear"></span>');
			text.push('</span>');
			return text.join("");
		
		},
		spinnerBindEvent : function(){
			var self = this,
				opt = self.configs;
			self.commonEvent();
			var text = $("#"+opt.id+"_text");
			$("span.ui-form-spinner-up",text).bind({
				click : function(e){
					self.fireEvent('onSpinnerUp',[]);
					self.fireEvent('onChange',[]);
					return false;
				},
				'mouseenter' : function(e){
					
					$(this).addClass('ui-form-spinner-up-over');
					
				},
				'mouseleave' : function(e){
					
					$(this).removeClass('ui-form-spinner-up-over');
				
				}	
			});
			$("span.ui-form-spinner-down",text).bind({
				click : function(e){
					self.fireEvent('onSpinnerDown',[]);
					self.fireEvent('onChange',[]);
					return false;
				},
				'mouseenter' : function(e){
					
					$(this).addClass('ui-form-spinner-down-over');
					
				},
				'mouseleave' : function(e){
					
					$(this).removeClass('ui-form-spinner-down-over');
				
				}	
			});
			return self;
		},
		spinnerCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var wraper = $( self.tpl(opt.type.toString(),opt) );
			
			var render = $(opt.renderTo);
			if( render.length ) {
				render.append( wraper );
			} else {
				target.after( wraper ).remove();
			}
			
			opt.helper = wraper;
		},
		radioSetValue : function(val){
			var self = this;
			var opt = self.configs;
			
			if( !arguments.length )  return self;
			
			var text = $("#"+opt.id+"_text");
			$(":radio[name='"+opt.name+"']",text).each(function(){
				$(this).removeAttr("checked");
				if( val == $(this).val() ) {
					$(this).attr("checked",'true');	
				}
			});
			
			return self;
		},
		radioTpl : function(d){
			if( !d ) return "";
			var self = this,
				opt = self.configs;
			var text = [];
			text.push('<span ui-form-group="'+d.group+'" style="'+d.display+'" class="ui-form-wraper '+d.cls+'" id="'+d.id+'">');
				text.push('<label for="'+d.id+'_input" class="ui-form-label '+d.labelCls+'">'+d.label+'</label>');
				text.push('<span class="ui-form-span ui-form-left-text">'+d.leftText+'</span>');
				text.push('<span class="ui-form-box" id="'+d.id+'_box">');
					text.push('<span class="ui-form-input ui-form-text" id="'+d.id+'_text" style=" width:0px;">');
						var items = opt.items;
						for(var i=0;i<items.length;i++) {
							if( !$.isPlainObject( items[i] ) ) {
								if( self.inArray( items[i] , [ '|',',',';' ] )!=-1 ) {
									text.push('<span class="ui-form-clear"></span>');	
								}
								continue;
							}
							items[i] = $.extend(true,{},opt._item,items[i]);
							if(items[i].disabled){
								items[i].attrs += 'disabled';
							}
							if(items[i].readOnly){
								items[i].attrs += ' readOnly ';
							}
							if(items[i].selected){
								items[i].attrs += ' checked ';
							}
							var str = '<span class=" ui-form-radio '+items[i].cls+'"><input id="'+opt.id+'_'+i+'" type="radio" value="'+items[i].name+'" name="'+opt.name+'" '+items[i].attrs+' ><label class = " ui-form-radio-label " for="'+opt.id+'_'+i+'">'+items[i]['value']+'</label></span>';
							text.push(str);
						}
						text.push('<span class="ui-form-buttons"></span>');
					text.push('</span>');
				text.push('</span>');
				text.push('<span class="ui-form-span ui-form-right-text">'+d.rightText+'</span>');
				text.push('<span class="ui-form-clear"></span>');
			text.push('</span>');
			return text.join("");
		},
		radioBindEvent : function(){
			var self = this;
			var opt = self.configs;
			var text = $("#"+opt.id+"_text");
			var radios = text.find(":radio[name='"+opt.name+"']");
			if( !radios.length ) {
				return self;
			}
			var events = {
				click : function(e) {
					var r = self.fireEvent('onClick',[ this,e ]);	
					if( r === false ) return false;
				}	
			};
			radios.bind(events);
		},
		radioCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var wraper = $( self.tpl(opt.type,opt) );
			
			var render = $(opt.renderTo);
			if( render.length ) {
				render.append( wraper );
			} else {
				target.after( wraper ).remove();
			}
			
			opt.helper = wraper;
		},
		checkboxSetValue : function(val){
			var self = this;
			var opt = self.configs;
			
			if( !arguments.length )  return self;
			
			var text = $("#"+opt.id+"_text");
			
			val = val.split(",");
			
			$(":checkbox[name='"+opt.name+"']",text).each(function(){
				$(this).removeAttr("checked");
				if( self.inArray( $(this).val(),val ) != -1 ) {
					$(this).attr("checked",'true');	
				}
			});
			
			return self;
		},
		checkboxTpl : function(d){
			if( !d ) return "";
			var self = this,
				opt = self.configs;
			var text = [];
			text.push('<span ui-form-group="'+d.group+'" style="'+d.display+'" class="ui-form-wraper '+d.cls+'" id="'+d.id+'">');
				text.push('<label for="'+d.id+'_input" class="ui-form-label '+d.labelCls+'">'+d.label+'</label>');
				text.push('<span class="ui-form-span ui-form-left-text">'+d.leftText+'</span>');
				text.push('<span class="ui-form-box" id="'+d.id+'_box">');
					text.push('<span class="ui-form-input ui-form-text" id="'+d.id+'_text" style=" width:0px;">');
						var items = opt.items;
						for(var i=0;i<items.length;i++) {
							if( !$.isPlainObject( items[i] ) ) {
								if( self.inArray( items[i] , [ '|',',',';' ] )!=-1 ) {
									text.push('<span class="ui-form-clear"></span>');	
								}
								continue;
							}
							items[i] = $.extend(true,{},opt._item,items[i]);
							if(items[i].disabled){
								items[i].attrs += 'disabled';
							}
							if(items[i].readOnly){
								items[i].attrs += ' readOnly ';
							}
							if(items[i].selected){
								items[i].attrs += ' checked ';
							}
							var str = '<span class=" ui-form-checkbox '+items[i].cls+'"><input id="'+opt.id+'_'+i+'" type="checkbox" value="'+items[i].name+'" name="'+opt.name+'" '+items[i].attrs+' ><label class = " ui-form-radio-label " for="'+opt.id+'_'+i+'">'+items[i]['value']+'</label></span>';
							text.push(str);
						}
						text.push('<span class="ui-form-buttons"></span>');
					text.push('</span>');
				text.push('</span>');
				text.push('<span class="ui-form-span ui-form-right-text">'+d.rightText+'</span>');
				text.push('<span class="ui-form-clear"></span>');
			text.push('</span>');
			return text.join("");
		},
		checkboxBindEvent : function(){
			var self = this;
			var opt = self.configs;
			var text = $("#"+opt.id+"_text");
			var checkbox = text.find(":checkbox[name='"+opt.name+"']");
			if( !checkbox.length ) {
				return self;
			}
			var events = {
				click : function(e) {
					self.fireEvent('onChange',[]);	
					var r = self.fireEvent('onClick',[ this,e ]);	
					if( r === false ) return false;
				}	
			};
			checkbox.bind(events);
		},
		checkboxCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var wraper = $( self.tpl(opt.type.toString(),opt) );
			
			var render = $(opt.renderTo);
			if( render.length ) {
				render.append( wraper );
			} else {
				target.after( wraper ).remove();
			}
			
			opt.helper = wraper;
		},
		textareaTpl : function(d){
			if( !d ) return "";
			var self = this,
				opt = self.configs;
			var text = [];
			text.push('<span ui-form-group="'+d.group+'" style="'+d.display+'" class="ui-form-wraper '+d.cls+'" id="'+d.id+'">');
				text.push('<label for="'+d.id+'_input" class="ui-form-label '+d.labelCls+'">'+d.label+'</label>');
				text.push('<span class="ui-form-span ui-form-left-text">'+d.leftText+'</span>');
				text.push('<span class="ui-form-box" id="'+d.id+'_box">');
					text.push('<span class="ui-form-input ui-form-text" id="'+d.id+'_text" style=" width:0px;">');
						text.push('<textarea id="'+d.id+'_input"  style=" width:0px; height:'+parseFloat(opt.height)+'px;" '+d.attrs+' name="'+opt.name+'">'+d.value+'</textarea>');
					text.push('</span>');
				text.push('</span>');
				text.push('<span class="ui-form-span ui-form-right-text">'+d.rightText+'</span>');
				text.push('<span class="ui-form-clear"></span>');
			text.push('</span>');
			return text.join("");
		},
		textareaBindEvent : function(){
			var self = this;
			self.commonEvent();
		},
		textareaCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var wraper = $( self.tpl(opt.type.toString(),opt) );
			
			var render = $(opt.renderTo);
			if( render.length ) {
				render.append( wraper );
			} else {
				target.after( wraper ).remove();
			}
			
			opt.helper = wraper;
		},
		//设置参数
		C : function(key,value){
			if( typeof key == 'undefined') {
				return this.configs;	
			}
			if( typeof value == 'undefined') {
				return this.configs[key];
			}
			this.configs[key] = value;
			return this;
		},
		getConf : function(){
			var self = this,
				opt = self.configs;
			var success = function(data){
						if( $.isPlainObject( data ) ) {
							opt = $.extend(opt,data);	
						}
						self.create();
					};
			var error = function(xmlHttp){
						self.create();
					};
			if( $.isFunction(opt.url) ) {
				opt.url.call(self,success,error);
			} else {
				$.ajax({
					url : opt.url,
					type : opt.method,
					dataType : opt.dataType,
					data : opt.queryParams,
					success : success,
					error : error
				});
			}
		},
		//清空
		reLoad :　function(){
			var self = this,
				opt = self.configs;
			//清空注册事件
			var events = opt.events;
			for( var x in events ) {
				events[x] = $.noop;	
			}
			self.init.call(self,opt);
			return self;
		}
	});
	

	
	$.fn.extform = function(_opt){
		if(this.size()<=0){
			//alert('容器不正确');
			return false;
		}
		var list = [];
		this.each(function(i){
			var self = $(this);
			
			var attrs = {
				type : $(this).attr('type'),	
				value : $(this).attr('value'),
				name : $(this).attr('name'),
				//width : $(this).attr('width'),
				//height : $(this).attr('height'),
				cls : $(this).attr('class'),
				rules : eval($(this).attr('rules') || '[]'),
				attrs : $(this).attr('attrs') || '',
				label : $(this).attr('label') || '',
				display : $(this).attr('display') || 'inline-block',
				group : $(this).attr('group') || 'default',
				disabled : $(this).attr('disabled'),
				readOnly : $(this).attr('readOnly')
			};
			var attrs2 = {};
			if( $(this).attr('data-options') ) {
				var attrs2 = eval('({'+$(this).attr('data-options')+'})');
			}
			
			var opt = $.extend(true,{},attrs,attrs2,_opt);

			opt.selector = self.selector;
			opt.helper = self;
			
			var extform = new $.extForm(opt);
			
			list.push(extform);
		});
		
		if( this.size() == 1 ) {
			return list[0];
		} else {
			return list	;
		}
	};
	
})(jQuery);
//radio
;(function($){
	"use strict";
	var radioInit = function(){
		var self = this;
		var opt = self.configs;
		var isRadio = opt.helper.is(":radio");
		if( isRadio ) {
			opt.type='radio';
			opt.onCheck.push("onChange");
			if( !opt.items.length ) {
				var items = [];
				var value = '';
				var label = $("label[for='"+opt.helper.attr("id")+"']");
				if( label.length ) {
					value = label.html();
					label.remove();
				} else if( typeof opt.helper.attr("label") != 'undefined' ) {
					value = opt.helper.attr("label");	
				}
				
				items.push({
					name : opt.helper.val(),
					value : value,
					disabled : opt.helper.attr("disabled"),
					selected : opt.helper.attr("checked"),
					readOnly : opt.helper.attr("readonly")
				});
				opt.width = 'auto';
				opt.items = items;
			}
		}
	};
	$.extForm.puglins.push(radioInit);
	$.extForm.fn.extend({
		radioSizeChange : function(width){
			var self = this;
			var opt = self.configs;
			
			var width = $.extForm._undef( width , opt.width );
			var text = $("#"+opt.id+"_text");
			
			text.width( width );
			
			$("#"+opt.id).height( $("#"+opt.id+"_box").outerHeight() );	
		}					
	});
})(jQuery);
//select
;(function($){
	"use strict";
	var selectInit = function(){
		var self = this;
		var opt = self.configs;
		//表单生成时
		if( opt.type=='multiselect' ) {
			opt.type='select';
			opt.multi = true;
			opt.onCheck.push("onChange");
		}
		
		var isSelect = opt.helper.is("select");
		
		if( isSelect  ) {
			
			opt.type='select';
			if( !opt.items.length ) {
				
				var items = [];
				opt.helper.find(">option").each(function(){
					var item = {};
					item.name = $(this).val();
					item.value = $(this).html();
					item.disabled = $(this).attr("disabled");
					item.selected = $(this).attr("selected");
					items.push(item);
				});	
				opt.items = items;
			
			}
		}
		if( opt.type == 'select' ) {
			opt.onCheck.push("onChange");	
		}
	};
	$.extForm.puglins.push(selectInit);
	$.extForm.fn.extend({
		
		selectExtend : function(){
			var self = this;
			var opt = self.configs;
			self.bind("onClick",self.showSelect,self);
			//默认选中项
			var self = this;
			var opt = self.configs;
			var items = opt.items;
			//var selects = opt.value.split(",");
			for( var x=0;x<items.length;x++ ) {
				items[x] = $.extend(true,{},opt._item,items[x]);
				if( items[x]['selected'] ) {
					self.selectSetValue( items[x].name,items[x].value );
				}
			}
			//创建显示下拉框
			self.creteSelectList();
		},
		selectStart : function(){
			var self = this;
			var opt = self.configs;
			opt.attrs += 'readonly';
		},
		selectDestroy : function(){
			var self = this;
			var opt = self.configs;
			$("#"+opt.id+"_list").remove();
		},
		selectGetValue : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input_key");
			return input.val();
		},
		//name,value
		selectSetValue : function(){
			var self = this;
			var opt = self.configs;
			var input = $("#"+opt.id+"_input");
			var input_key = $("#"+opt.id+"_input_key");	
			
			if( arguments.length == 2 ) {
				input.val(arguments[1]);
				input_key.val(arguments[0]);
			} else {
				//input.val(arguments[0]);
				//input_key.val(arguments[0]);	
				if( opt.multi ) {
					$.each( arguments[0].split(","),function(i,value){
						self.selectItem(value);				  
					} );	
				} else {
					self.selectItem(arguments[0]);
				}
			}
			
			return self;
		},
		selectValueChange : function(){
			var self = this;
		//	self.fireEvent("onChange");
			return self;	
		},
		selectBindEvent : function(){
			var self = this;
			var opt = self.configs;
			self.commonEvent();
			var obj = $("#"+opt.id+"_text");
			obj.bind("click",function(){
				//return false;						  
			})
			return self;	
		},
		selectCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var render = $(opt.renderTo);
			
			var wraper = $( self.tpl('combo',opt) );
			
			if( render.length ) {
				render.append( wraper );
			} else {
				target.after( wraper ).remove();
			}
			opt.helper = wraper;
		},
		selectUpdateValue :　function(){
			var self = this;
			var opt = self.configs;
			var selects = $("#"+opt.id+"_list_body").find(">div.ui-form-select-list-item-selected");
			var name = [];
			var value = []
			selects.each(function(){
				name.push($(this).attr("value"));		
				value.push($(this).html());		
			});
			self.val( name.join(","),value.join(",") );
			return self;
		},
		creteSelectList : function(){
			var self = this;
			var opt = self.configs;
			var list = [];
			//创建
			list.push('<div id="'+opt.id+'_list" class="ui-form-select-list" tabindex="-1" style="display:none;">');
				list.push('<div id="'+opt.id+'_list_body" class="ui-form-select-list-body" tabindex="-1" style="">');
					var items = opt.items;
					for( var x=0;x<items.length;x++ ) {
						items[x] = $.extend(true,{},opt._item,items[x]);
						if( items[x]['disabled'] ) {
							items[x]['cls'] += ' ui-form-select-list-item-disabled ';	
						}
						if( items[x]['selected'] ) {
							items[x]['cls'] += ' ui-form-select-list-item-selected ';
						}
						list.push('<div value="'+items[x]['name']+'" class="ui-form-select-list-item '+items[x]['cls']+'" id="'+opt.id+'_'+x+'_item">'+items[x]['value']+'</div>');	
					}
					
				list.push('</div>');
			list.push('</div>');
			
			list = $( list.join("") ).appendTo(document.body);
			
			//事件绑定
			var events = {
				selectstart : function(e){
					return false;	
				},
				mouseenter : function(e){
					if( $(this).hasClass('ui-form-select-list-item-disabled') ) return;
					$(this).addClass("ui-form-select-list-item-over");
				},
				mouseleave : function(e){
					if( $(this).hasClass('ui-form-select-list-item-disabled') ) return;
					$(this).removeClass("ui-form-select-list-item-over");
				},
				click : function(e) {
					if( $(this).hasClass('ui-form-select-list-item-disabled') ) return false;
					var name = $(this).attr('value');
					var value = $(this).html();
					opt.multi = $.extForm._undef(opt.multi,false);
					if( !opt.multi ) {//单选
						$("#"+opt.id+"_list_body").find(">div.ui-form-select-list-item").removeClass("ui-form-select-list-item-selected");
						$(this).addClass("ui-form-select-list-item-selected");
						//self.val(name,value);
						self.selectUpdateValue();		
						self.hideSelect();
						return false;//事件冒泡
					} else {//多选
						
						if( $(this).hasClass("ui-form-select-list-item-selected") ) {
							$(this).removeClass("ui-form-select-list-item-selected");
						} else {
							$(this).addClass("ui-form-select-list-item-selected");
						}
						
						self.selectUpdateValue();
						
						return false;
					}
					
				}
			};
			$(".ui-form-select-list-item",list).bind(events);
				
			return list;
		},
		destroySelectList : function(){
			var self = this;
			var opt = self.configs;
			
			var list = $('#'+opt.id+'_list');
			
			list.remove();
			$(document).unbind("click.selectList"+opt.id);	
			$(document).unbind("keydown.selectList"+opt.id);		
		},
		hideSelect : function(){
			var self = this;
			var opt = self.configs;
			
			var list = $('#'+opt.id+'_list');
			list.css({
				width:'auto',
				height:'auto'
			});
			list.hide();
			$(document).unbind("keydown.selectList"+opt.id);		
		},
		selectItem : function(name){
			var self = this;
			var opt = self.configs;	
			name = $.extForm._undef(name,false);
			if( name === false ) return self;
			
			var items = opt.items;
			
			opt.multi = $.extForm._undef(opt.multi,false);
			if( !opt.multi ) {//单选模式下
				$("#"+opt.id+"_list_body").find(">div.ui-form-select-list-item").removeClass("ui-form-select-list-item-selected");	
			}
			
			for( var x=0;x<items.length;x++ ) {
				items[x] = $.extend(true,{},opt._item,items[x]);
				if( items[x].name == name ) {
					$("#"+opt.id+'_'+x+"_item").removeClass("ui-form-select-list-item-selected")
											   .addClass("ui-form-select-list-item-selected");
					break;
				}
			}
			self.selectUpdateValue();
			return self;
		},
		unSelectItem : function(name){
			var self = this;
			var opt = self.configs;	
			name = $.extForm._undef(name,false);
			if( name === false ) return self;
			
			var items = opt.items;
			for( var x=0;x<items.length;x++ ) {
				items[x] = $.extend(true,{},opt._item,items[x]);
				if( items[x].name == name ) {
					$("#"+opt.id+'_'+x+"_item").removeClass("ui-form-select-list-item-selected");
					break;
				}
			}	
			self.selectUpdateValue();
			return self;
		},
		
		showSelect : function(input){
			
			if( $(input).attr("disabled") ){
				return self;	
			}
			
			var self = this;
			var opt = self.configs;
			
			if( opt.readonly ) {
				return self;	
			}
			
			var list = $('#'+opt.id+'_list');
			var obj = $("#"+opt.id+"_text");
			var space = self.getShowSpace();
			//取消绑定
			$(document).unbind("click.selectList"+opt.id);		
			$(document).unbind("keydown.selectList"+opt.id);		
			//判断是否创建
			if( !list.length ) {
				list = self.creteSelectList();
			}
			
			var sbody = $("#"+opt.id+"_list_body");
			sbody.find(">div.ui-form-select-list-item").removeClass("ui-form-select-list-item-over");
			
			if( !list.is(":hidden") ) {
				self.hideSelect();
				return self;
			}
			
			//显示
			var h = list.outerHeight();
			var w = list.outerWidth();
			var offset = obj.offset();
			var border_top = parseInt( list.css("border-top-width") );
			var border_bottom = parseInt( list.css("border-bottom-width") );
			var border_left = parseInt( list.css("border-left-width") );
			var border_right = parseInt( list.css("border-right-width") );
			
			
			opt.maxHeight = $.extForm._undef(opt.maxHeight,Math.max(space.bottom,space.top));
			opt.maxWidth = $.extForm._undef(opt.maxWidth, obj.outerWidth() );
			
			list.removeClass('ui-form-select-list-bottom-auto')
				.removeClass('ui-form-select-list-top-auto')
				.removeClass('ui-form-select-list-top')
				.removeClass('ui-form-select-list-bottom');
			
			//计算大小
			if( h>opt.maxHeight ) {
				h = opt.maxHeight;		
			}
			
			
			//显示方位
			var showPos = 'bottom';
			if( h<=space.bottom) {//显示在下方
				list.css({
					top : offset.top + obj.outerHeight(),
					left : offset.left
						 });
				list.addClass('ui-form-select-list-bottom');
			} else if( space.top > space.bottom ) {//显示在上方
				list.css({
					top:offset.top - h,
					left : offset.left
						 });
				list.addClass('ui-form-select-list-top');
				showPos = 'top';
			} else {//显示在下方
				list.css({
					top : offset.top + obj.outerHeight(),
					left : offset.left
						 });
				list.addClass('ui-form-select-list-bottom');	
			}
			
			h = h - border_top - border_bottom;
			
			list.height( h );	
			
			
			if( opt.maxWidth == 'auto' ) {
				if( w < obj.outerWidth() ) {
					w = obj.outerWidth();
				} else {
					if( w > ( space.right+obj.outerWidth() ) ) {
						list.addClass("ui-form-select-list-"+showPos+"-auto");
						w = space.right+obj.outerWidth();
					} else if( w<obj.outerWidth() ) {
						w = obj.outerWidth();	
					} else {
						list.addClass("ui-form-select-list-"+showPos+"-auto");	
					}
				}
			} else {
				if( w >= opt.maxWidth && w > obj.outerWidth() ) {
					list.addClass("ui-form-select-list-"+showPos+"-auto");
					w = opt.maxWidth;		
				} else {
					w = obj.outerWidth();	
				}
				
			}
			
			w = w - border_left - border_right;
			list.width( w );
			
			list.show();
			
			//取消绑定
			setTimeout(function(){
				$(document).bind("click.selectList"+opt.id,function(e){
					self.hideSelect();											 
				});	
				$(document).bind("keydown.selectList"+opt.id,function(e){
					var sbody = $("#"+opt.id+"_list_body");
					var s = sbody.find(".ui-form-select-list-item-over:last");
					if( !s.size() ) {
						s = sbody.find(">div.ui-form-select-list-item-selected:last");
						if( !s.size() ) {
							s = sbody.find(".ui-form-select-list-item:first");	
						}
					}
					
					if( !s.size() ) return;
					
					switch( e.keyCode ) {
						case 38 : //up
							sbody.find(">div.ui-form-select-list-item").removeClass("ui-form-select-list-item-over");
							var prev = s.prev();
							if( prev.size() ) {
								prev.addClass("ui-form-select-list-item-over");	
							} else {
								s.addClass("ui-form-select-list-item-over");		
							}
							break;
						case 40 : //down
							sbody.find(">div.ui-form-select-list-item").removeClass("ui-form-select-list-item-over");
							var next = s.next();
							if( next.size() ) {
								next.addClass("ui-form-select-list-item-over");	
							} else {
								s.addClass("ui-form-select-list-item-over");		
							}
							break;
						case 13:
							sbody.find(">div.ui-form-select-list-item-over").click();
							break;
					}
					return false;
				});	
			},0);
			
		}
	});
})(jQuery);
//checkbox
;(function($){
	"use strict";
	var checkboxInit = function(){
		var self = this;
		var opt = self.configs;
		var isCheckbox = opt.helper.is(":checkbox");
		if( isCheckbox ) {
			opt.type='checkbox';
			opt.onCheck.push("onChange");
			if( !opt.items.length ) {
				var items = [];
				var value = '';
				var label = $("label[for='"+opt.helper.attr("id")+"']");
				if( label.length ) {
					value = label.html();
					label.remove();
				} else if( typeof opt.helper.attr("label") != 'undefined' ) {
					value = opt.helper.attr("label");	
				}
				
				items.push({
					name : opt.helper.val(),
					value : value,
					disabled : opt.helper.attr("disabled"),
					selected : opt.helper.attr("checked"),
					readOnly : opt.helper.attr("readonly")
				});
				opt.width = 'auto';
				opt.items = items;
			}
		}
	};
	$.extForm.puglins.push(checkboxInit);
	$.extForm.fn.extend({
		checkboxSizeChange : function(width){
			var self = this;
			var opt = self.configs;
			
			var width = $.extForm._undef( width , opt.width );
			var text = $("#"+opt.id+"_text");
			
			text.width( width );
			
			$("#"+opt.id).height( $("#"+opt.id+"_box").outerHeight() );	
		}					
	});
})(jQuery);
//date
;(function($){
	"use strict";
	$.extForm.fn.extend({
		dateExtend : function(){
			var self = this;
			var opt = self.configs;
			self.val( opt.value );
		},
		dateStart : function(){
			var self = this;
			var opt = self.configs;
			//opt.cls +=" date-picker ";
			
			//opt.attrs += ' class="date-picker" ';
			//opt.attrs += ' data-date-format="'+dateFormat+'" ';
			
			opt.onCheck.push("onChange");
		},
		dateBindEvent : function(){
			var self = this;
			var opt = self.configs;
			self.commonEvent();
			var text = $("#"+opt.id+"_text");
			$(">span.ui-form-buttons",text).bind({
				click : function(e){
					$("#"+opt.id+"_input")[0].focus();
					return false;
				}						 
			});
			$("#"+opt.id+"_input").blur(function(){
				$("#"+opt.id+"_input_key").val( $("#"+opt.id+"_input").val() );
				setTimeout(function(){
					self.fireEvent('onChange');
					self.checkVal();						
				},10);
			});
			$("#"+opt.id+"_input").change(function(){
				$("#"+opt.id+"_input_key").val( $("#"+opt.id+"_input").val() );								 
			});
			
			var dateFormat = opt.dateFormate || opt.helper.attr("date-format") || 'yyyy-mm-dd';
			
			var isIE6_7 = false;
			var browser=navigator.appName 
			var b_version=navigator.appVersion 
			var version=b_version.split(";"); 
			try{
			var trim_Version=version[1].replace(/[ ]/g,""); 
			} catch(e) {
				trim_Version = ''	
			}
			if(browser=="Microsoft Internet Explorer" && trim_Version=="MSIE7.0") 
			{ 
			isIE6_7 = true;
			} 
			else if(browser=="Microsoft Internet Explorer" && trim_Version=="MSIE6.0") 
			{ 
			isIE6_7 = true;
			} 
			if( isIE6_7 ) {
				
				$("#"+opt.id+"_input").click(function(){
					var self = this;
					WdatePicker({el:self});									  
				});
			} else {
				$("#"+opt.id+"_input").attr("onClick","WdatePicker()");
			}
			return self;	
		},
		
		dateCreate : function(){
			var self = this;
			var opt = self.configs;
			var target = opt.helper;
			
			var render = $(opt.renderTo);
			
			var wraper = $( self.tpl('combo',opt) );
			
			if( render.length ) {
				render.append( wraper );
			} else {
				target.after( wraper ).remove();
			}
			
			opt.helper = wraper;	
		}
	});
})(jQuery);
//spinner
;(function($){
	"use strict";
	var spinnerInit = function(){
		var self = this;
		var opt = self.configs;
		//js 浮点运算BUG eg: 7*0.8
		/*var fixFloat = function(num,step){
			var step = step.toString().split(".");
			if( step.length == 1 ) {
				return num;	
			}
			var l = step[1].length;
			var num = num.toString().split(".");
			if( num[1].length ) {
				num[1].substr(0,l);
			}
			return Number( num.join(".") );
		}*/
		var onSpinnerUp = function(){
			var self = this;
			var opt = self.configs;	
			opt.step = Number( opt.step );
			var v = Number(self.val())+opt.step
			if( opt.smax !== null ) {
				if( v>opt.smax ) return;
			}
			self.val( v );
		};
		var onSpinnerDown = function(){
			var self = this;
			var opt = self.configs;		
			opt.step = Number( opt.step );
			var v = Number(self.val())-opt.step
			if( opt.smin !== null ) {
				if( v<opt.smin ) return;
			}
			self.val( v );
		};
		if( opt.type=='spinner' ) {
			opt.onCheck.push("onChange");
			self.bind("onSpinnerUp",onSpinnerUp);
			self.bind("onSpinnerDown",onSpinnerDown);
			if( opt.smax !== null ) {
				opt.rules.push( {max:Number(opt.smax)} );
			}
			if( opt.smin !== null ) {
				opt.rules.push( {min:Number(opt.smin)} );
			}
		}
	};
	$.extForm.puglins.push(spinnerInit);
})(jQuery);
//联动下拉框
;(function($){
	"use strict";
	var stagselectInit = function(){
		var self = this;
		var opt = self.configs;
		function change(){
			var self = this;
			var opt = self.configs;
			var items = self.C('items');
			var value = self.val();
			
			$("#"+opt.id).nextAll('.stag_'+opt.id).remove();
			
			$.each(items,function(i,item){
				if( item.name == value && item.sub!='' ) {
					var _opt = {};
					_opt.url = item.sub;
					_opt.type = 'stagselect';
					_opt.id = '';
					_opt.renderTo = '#'+opt.id;
					_opt.onCreate = function(){
						$("#"+opt.id).after($("#"+this.C('id')));
					}
					var ipt = $("#"+opt.id).extform(_opt);
					
					return false;
				}
			});
			console.log( self.val() );
		}
		if( opt.type == 'stagselect'  ) {
			opt.onCheck.push("onChange");
			opt.type='select';
			opt.cls += ' stag_'+opt.id+' ';
			self.bind("onChange",change);
		}
	};
	$.extForm.puglins.push(stagselectInit);
})(jQuery);
//text
;(function($){
	"use strict";
	var textInit = function(){
		var self = this;
		var opt = self.configs;
		var isText = opt.helper.is(":text");
		if( isText ) {
			opt.type='text';		
		}
	};
	$.extForm.puglins.push(textInit);
})(jQuery);
//textarea
;(function($){
	"use strict";
	var textareaInit = function(){
		var self = this;
		var opt = self.configs;
		var isTextarea = opt.helper.is("textarea");
		if( isTextarea ) {
			opt.type='textarea';
			opt.width = opt.helper.width();
			opt.height = opt.helper.height();
		}
	};
	$.extForm.puglins.push(textareaInit);
})(jQuery);
