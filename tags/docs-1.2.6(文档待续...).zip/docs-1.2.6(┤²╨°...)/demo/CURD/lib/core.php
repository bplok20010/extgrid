<?php
error_reporting(E_ALL & ~ E_NOTICE);
require_once('model/index.php');
?>