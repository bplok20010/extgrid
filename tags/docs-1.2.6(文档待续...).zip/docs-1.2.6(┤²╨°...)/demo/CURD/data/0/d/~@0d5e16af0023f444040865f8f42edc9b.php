<?php
//000000000000s:36:"SELECT * FROM `extgrid` LIMIT 0,50  ";
?>